# Usage

## Build Project

        $ make

## Running Find Physical Address Application

        $ sudo ./app

## Clean Project

        $ make clean

# Caution
Never change the app.c and debugfs file name.
